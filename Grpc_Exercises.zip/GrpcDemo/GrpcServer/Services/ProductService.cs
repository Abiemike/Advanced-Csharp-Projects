﻿using System.Text.Json.Serialization;
using Google.Protobuf.WellKnownTypes;
using Grpc.Core;
using Newtonsoft.Json;

namespace GrpcServer.Services
{
    public class ProductService:GrpcServer.ProductService.ProductServiceBase
    {
        private readonly ILogger<ProductService> _logger;
        private readonly IHttpClientFactory _httpClientFactory;

        public ProductService(ILogger<ProductService> logger, IHttpClientFactory httpClientFactory)
        {
            _logger = logger;
            _httpClientFactory = httpClientFactory;
        }

        public override async Task<ProductResponse> GetProductById(GetById request, ServerCallContext context)
        {
            var httpClient = _httpClientFactory.CreateClient("productApi");
            var response = await httpClient.GetAsync(new Uri($"products/{request.Id}", UriKind.Relative));
            response.EnsureSuccessStatusCode();

            var product = JsonConvert.DeserializeObject<ProductResponse>(await response.Content.ReadAsStringAsync());

            if (product != null)
            {
                _logger.LogInformation("Details related to product id: {0}, product name: {1} was successfully returned"
                    ,request.Id,product.Title);
            }
            else
            {
                _logger.LogError("Error: {0} at {1}", response.ReasonPhrase, DateTime.UtcNow);
            }

            product!.LastUpdated = Timestamp.FromDateTime(DateTime.UtcNow);
            return product;
        }
    }
}
