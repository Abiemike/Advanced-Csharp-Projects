using GrpcServer;
using ProductService = GrpcServer.Services.ProductService;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddGrpc();

builder.Services.AddHttpClient("productApi", options =>
{
    options.BaseAddress = new Uri(builder.Configuration.GetSection("ApiOptions:BaseAddress").Value);
});

var app = builder.Build();

// Configure the HTTP request pipeline.
app.MapGrpcService<ProductService>();

app.MapGet("/", () => "Communication with gRPC endpoints must be made through a gRPC client. To learn how to create a client, visit: https://go.microsoft.com/fwlink/?linkid=2086909");

app.Run();
