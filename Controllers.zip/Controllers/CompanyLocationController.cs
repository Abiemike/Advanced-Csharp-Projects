﻿using CareerCloud.BusinessLogicLayer;
using CareerCloud.Pocos;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;

namespace CareerCloud.Controllers
{
    [Route("api/careercloud/company/locations/v1")]
    [ApiController]
    public class CompanyLocationController : ControllerBase
    {
        private readonly CompanyLocationLogic _companyLocationLogic;

        // Constructor for dependency injection of the business logic layer
        public CompanyLocationController(CompanyLocationLogic companyLocationLogic)
        {
            _companyLocationLogic = companyLocationLogic;
        }

        public CompanyLocationController()
        {
        }

        // GET: api/CompanyLocations
        // Get all company locations
        [HttpGet]
        public IActionResult GetAllCompanyLocations()
        {
            List<CompanyLocationPoco> companyLocations = _companyLocationLogic.GetAll();

            if (companyLocations == null || companyLocations.Count == 0)
            {
                return NotFound("No company locations found.");
            }

            return Ok(companyLocations);
        }

        // GET: api/CompanyLocations/{id}
        // Get a specific company location by id
        [HttpGet("{id}")]
        public IActionResult GetCompanyLocation(Guid id)
        {
            CompanyLocationPoco companyLocation = _companyLocationLogic.Get(id);

            if (companyLocation == null)
            {
                return NotFound($"Company Location with id {id} not found.");
            }

            return Ok(companyLocation);
        }

        // POST: api/CompanyLocations
        // Create a new company location
        [HttpPost]
        public IActionResult CreateCompanyLocation([FromBody] CompanyLocationPoco companyLocation)
        {
            if (companyLocation == null)
            {
                return BadRequest("Company location cannot be null.");
            }

            // Call the business logic to add the new company location
            _companyLocationLogic.Add(companyLocation);

            return CreatedAtAction(nameof(GetCompanyLocation), new { id = companyLocation.Id }, companyLocation);
        }

        // PUT: api/CompanyLocations/{id}
        // Update an existing company location by id
        [HttpPut("{id}")]
        public IActionResult UpdateCompanyLocation(Guid id, [FromBody] CompanyLocationPoco companyLocation)
        {
            if (companyLocation == null || companyLocation.Id != id)
            {
                return BadRequest("Invalid company location data.");
            }

            // Ensure the company location exists
            var existingCompanyLocation = _companyLocationLogic.Get(id);
            if (existingCompanyLocation == null)
            {
                return NotFound($"Company Location with id {id} not found.");
            }

            // Call the business logic to update the company location
            _companyLocationLogic.Update(companyLocation);

            return NoContent(); // Successfully updated
        }

        // DELETE: api/CompanyLocations/{id}
        // Delete a company location by id
        [HttpDelete("{id}")]
        public IActionResult DeleteCompanyLocation(Guid id)
        {
            // Ensure the company location exists before attempting to delete
            var companyLocation = _companyLocationLogic.Get(id);
            if (companyLocation == null)
            {
                return NotFound($"Company Location with id {id} not found.");
            }

            // Call the business logic to delete the company location
            _companyLocationLogic.Delete(id);

            return NoContent(); // Successfully deleted
        }

        public IActionResult DeleteCompanyLocation(CompanyLocationPoco[] companyLocationPocos)
        {
            throw new NotImplementedException();
        }

        public ActionResult PostCompanyLocation(CompanyLocationPoco[] companyLocationPocos)
        {
            throw new NotImplementedException();
        }

        public ActionResult PutCompanyLocation(CompanyLocationPoco[] companyLocationPocos)
        {
            throw new NotImplementedException();
        }
    }
}
