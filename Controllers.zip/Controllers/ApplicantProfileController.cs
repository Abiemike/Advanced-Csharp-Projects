﻿using CareerCloud.BusinessLogicLayer;
using CareerCloud.Pocos;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;

namespace CareerCloud.Controllers
{
    [Route("api/careercloud/applicant/profile/v1")]
    [ApiController]
    public class ApplicantProfileController : ControllerBase
    {
        private readonly ApplicantProfileLogic _applicantProfileLogic;

        // Constructor for dependency injection of the business logic layer
        public ApplicantProfileController(ApplicantProfileLogic applicantProfileLogic)
        {
            _applicantProfileLogic = applicantProfileLogic;
        }

        public ApplicantProfileController()
        {
        }

        // GET: api/ApplicantProfile
        // Get all applicant profiles
        [HttpGet]
        public IActionResult GetAllApplicantProfiles()
        {
            List<ApplicantProfilePoco> applicantProfiles = _applicantProfileLogic.GetAll();

            if (applicantProfiles == null || applicantProfiles.Count == 0)
            {
                return NotFound("No applicant profiles found.");
            }

            return Ok(applicantProfiles);
        }

        // GET: api/ApplicantProfile/{id}
        // Get a specific applicant profile by id
        [HttpGet("{id}")]
        public IActionResult GetApplicantProfile(Guid id)
        {
            ApplicantProfilePoco applicantProfile = _applicantProfileLogic.Get(id);

            if (applicantProfile == null)
            {
                return NotFound($"Applicant Profile with id {id} not found.");
            }

            return Ok(applicantProfile);
        }

        // POST: api/ApplicantProfile
        // Create a new applicant profile
        [HttpPost]
        public IActionResult CreateApplicantProfile([FromBody] ApplicantProfilePoco applicantProfile)
        {
            if (applicantProfile == null)
            {
                return BadRequest("Applicant profile cannot be null.");
            }

            // Call the business logic to add the new applicant profile
            _applicantProfileLogic.Add(applicantProfile);

            return CreatedAtAction(nameof(GetApplicantProfile), new { id = applicantProfile.Id }, applicantProfile);
        }

        // PUT: api/ApplicantProfile/{id}
        // Update an existing applicant profile by id
        [HttpPut("{id}")]
        public IActionResult UpdateApplicantProfile(Guid id, [FromBody] ApplicantProfilePoco applicantProfile)
        {
            if (applicantProfile == null || applicantProfile.Id != id)
            {
                return BadRequest("Invalid applicant profile data.");
            }

            // Ensure the applicant profile exists
            var existingApplicantProfile = _applicantProfileLogic.Get(id);
            if (existingApplicantProfile == null)
            {
                return NotFound($"Applicant Profile with id {id} not found.");
            }

            // Call the business logic to update the applicant profile
            _applicantProfileLogic.Update(applicantProfile);

            return NoContent(); // Successfully updated
        }

        // DELETE: api/ApplicantProfile/{id}
        // Delete an applicant profile by id
        [HttpDelete("{id}")]
        public IActionResult DeleteApplicantProfile(Guid id)
        {
            // Ensure the applicant profile exists before attempting to delete
            var applicantProfile = _applicantProfileLogic.Get(id);
            if (applicantProfile == null)
            {
                return NotFound($"Applicant Profile with id {id} not found.");
            }

            // Call the business logic to delete the applicant profile
            _applicantProfileLogic.Delete(id);

            return NoContent(); // Successfully deleted
        }

        public ActionResult PostApplicantProfile(ApplicantProfilePoco[] applicantProfilePocos)
        {
            throw new NotImplementedException();
        }

        public ActionResult DeleteApplicantProfile(ApplicantProfilePoco[] applicantProfilePocos)
        {
            throw new NotImplementedException();
        }

        public ActionResult PutApplicantProfile(ApplicantProfilePoco[] applicantProfilePocos)
        {
            throw new NotImplementedException();
        }
    }
}
