﻿using CareerCloud.BusinessLogicLayer;
using CareerCloud.Pocos;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;

namespace CareerCloud.Controllers
{
    [Route("api/careercloud/company/jobskill/v1")]
    [ApiController]
    public class CompanyJobSkillController : ControllerBase
    {
        private readonly CompanyJobSkillLogic _companyJobSkillLogic;

        // Constructor for dependency injection of the business logic layer
        public CompanyJobSkillController(CompanyJobSkillLogic companyJobSkillLogic)
        {
            _companyJobSkillLogic = companyJobSkillLogic;
        }

        public CompanyJobSkillController()
        {
        }

        // GET: api/CompanyJobSkills
        // Get all company job skills
        [HttpGet]
        public IActionResult GetAllCompanyJobSkills()
        {
            List<CompanyJobSkillPoco> companyJobSkills = _companyJobSkillLogic.GetAll();

            if (companyJobSkills == null || companyJobSkills.Count == 0)
            {
                return NotFound("No company job skills found.");
            }

            return Ok(companyJobSkills);
        }

        // GET: api/CompanyJobSkills/{id}
        // Get a specific company job skill by id
        [HttpGet("{id}")]
        public IActionResult GetCompanyJobSkill(Guid id)
        {
            CompanyJobSkillPoco companyJobSkill = _companyJobSkillLogic.Get(id);

            if (companyJobSkill == null)
            {
                return NotFound($"Company Job Skill with id {id} not found.");
            }

            return Ok(companyJobSkill);
        }

        // POST: api/CompanyJobSkills
        // Create a new company job skill
        [HttpPost]
        public IActionResult CreateCompanyJobSkill([FromBody] CompanyJobSkillPoco companyJobSkill)
        {
            if (companyJobSkill == null)
            {
                return BadRequest("Company job skill cannot be null.");
            }

            // Call the business logic to add the new company job skill
            _companyJobSkillLogic.Add(companyJobSkill);

            return CreatedAtAction(nameof(GetCompanyJobSkill), new { id = companyJobSkill.Id }, companyJobSkill);
        }

        // PUT: api/CompanyJobSkills/{id}
        // Update an existing company job skill by id
        [HttpPut("{id}")]
        public IActionResult UpdateCompanyJobSkill(Guid id, [FromBody] CompanyJobSkillPoco companyJobSkill)
        {
            if (companyJobSkill == null || companyJobSkill.Id != id)
            {
                return BadRequest("Invalid company job skill data.");
            }

            // Ensure the company job skill exists
            var existingCompanyJobSkill = _companyJobSkillLogic.Get(id);
            if (existingCompanyJobSkill == null)
            {
                return NotFound($"Company Job Skill with id {id} not found.");
            }

            // Call the business logic to update the company job skill
            _companyJobSkillLogic.Update(companyJobSkill);

            return NoContent(); // Successfully updated
        }

        // DELETE: api/CompanyJobSkills/{id}
        // Delete a company job skill by id
        [HttpDelete("{id}")]
        public IActionResult DeleteCompanyJobSkill(Guid id)
        {
            // Ensure the company job skill exists before attempting to delete
            var companyJobSkill = _companyJobSkillLogic.Get(id);
            if (companyJobSkill == null)
            {
                return NotFound($"Company Job Skill with id {id} not found.");
            }

            // Call the business logic to delete the company job skill
            _companyJobSkillLogic.Delete(id);

            return NoContent(); // Successfully deleted
        }

        public ActionResult PostCompanyJobSkill(CompanyJobSkillPoco[] companyJobSkillPocos)
        {
            throw new NotImplementedException();
        }

        public ActionResult PutCompanyJobSkill(CompanyJobSkillPoco[] companyJobSkillPocos)
        {
            throw new NotImplementedException();
        }

        public IActionResult DeleteCompanyJobSkill(CompanyJobSkillPoco[] companyJobSkillPocos)
        {
            throw new NotImplementedException();
        }
    }
}
