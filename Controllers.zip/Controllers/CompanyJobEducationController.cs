﻿using CareerCloud.BusinessLogicLayer;
using CareerCloud.Pocos;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;

namespace CareerCloud.Controllers
{
    [Route("api/careercloud/company/jobeducation/v1")]
    [ApiController]
    public class CompanyJobEducationController : ControllerBase
    {
        private readonly CompanyJobEducationLogic _companyJobEducationLogic;

        // Constructor for dependency injection of the business logic layer
        public CompanyJobEducationController(CompanyJobEducationLogic companyJobEducationLogic)
        {
            _companyJobEducationLogic = companyJobEducationLogic;
        }

        public CompanyJobEducationController()
        {
        }

        // GET: api/CompanyJobEducation
        // Get all company job education details
        [HttpGet]
        public IActionResult GetAllCompanyJobEducation()
        {
            List<CompanyJobEducationPoco> companyJobEducations = _companyJobEducationLogic.GetAll();

            if (companyJobEducations == null || companyJobEducations.Count == 0)
            {
                return NotFound("No company job education details found.");
            }

            return Ok(companyJobEducations);
        }

        // GET: api/CompanyJobEducation/{id}
        // Get a specific company job education by id
        [HttpGet("{id}")]
        public IActionResult GetCompanyJobEducation(Guid id)
        {
            CompanyJobEducationPoco companyJobEducation = _companyJobEducationLogic.Get(id);

            if (companyJobEducation == null)
            {
                return NotFound($"Company Job Education with id {id} not found.");
            }

            return Ok(companyJobEducation);
        }

        // POST: api/CompanyJobEducation
        // Create a new company job education detail
        [HttpPost]
        public IActionResult CreateCompanyJobEducation([FromBody] CompanyJobEducationPoco companyJobEducation)
        {
            if (companyJobEducation == null)
            {
                return BadRequest("Company job education cannot be null.");
            }

            // Call the business logic to add the new company job education
            _companyJobEducationLogic.Add(companyJobEducation);

            return CreatedAtAction(nameof(GetCompanyJobEducation), new { id = companyJobEducation.Id }, companyJobEducation);
        }

        // PUT: api/CompanyJobEducation/{id}
        // Update an existing company job education detail by id
        [HttpPut("{id}")]
        public IActionResult UpdateCompanyJobEducation(Guid id, [FromBody] CompanyJobEducationPoco companyJobEducation)
        {
            if (companyJobEducation == null || companyJobEducation.Id != id)
            {
                return BadRequest("Invalid company job education data.");
            }

            // Ensure the company job education exists
            var existingCompanyJobEducation = _companyJobEducationLogic.Get(id);
            if (existingCompanyJobEducation == null)
            {
                return NotFound($"Company Job Education with id {id} not found.");
            }

            // Call the business logic to update the company job education
            _companyJobEducationLogic.Update(companyJobEducation);

            return NoContent(); // Successfully updated
        }

        // DELETE: api/CompanyJobEducation/{id}
        // Delete a company job education detail by id
        [HttpDelete("{id}")]
        public IActionResult DeleteCompanyJobEducation(Guid id)
        {
            // Ensure the company job education exists before attempting to delete
            var companyJobEducation = _companyJobEducationLogic.Get(id);
            if (companyJobEducation == null)
            {
                return NotFound($"Company Job Education with id {id} not found.");
            }

            // Call the business logic to delete the company job education
            _companyJobEducationLogic.Delete(id);

            return NoContent(); // Successfully deleted
        }

        public IActionResult DeleteCompanyJobEducation(CompanyJobEducationPoco[] companyJobEducationPocos)
        {
            throw new NotImplementedException();
        }

        public ActionResult PostCompanyJobEducation(CompanyJobEducationPoco[] companyJobEducationPocos)
        {
            throw new NotImplementedException();
        }

        public ActionResult PutCompanyJobEducation(CompanyJobEducationPoco[] companyJobEducationPocos)
        {
            throw new NotImplementedException();
        }
    }
}
