﻿using CareerCloud.BusinessLogicLayer;
using CareerCloud.Pocos;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;


namespace CareerCloud.Controllers
{
    [Route("api/careercloud/company/jobdescription/v1")]
    [ApiController]
    public class CompanyJobsDescriptionController : ControllerBase
    {
       private readonly CompanyJobDescriptionLogic _companyJobDescriptionLogic;

        // Constructor for dependency injection of the business logic layer
        public CompanyJobsDescriptionController() { }
        //{
        //    _companyJobDescriptionLogic = companyJobDescriptionLogic;
        //}

        public CompanyJobsDescriptionController(CompanyJobDescriptionLogic companyJobDescriptionLogic)
        {
            _companyJobDescriptionLogic = companyJobDescriptionLogic;
        }

        // GET: api/CompanyJobDescription
        // Get all company job descriptions
        [HttpGet]
        public IActionResult GetAllCompanyJobDescriptions()
        {
            List<CompanyJobDescriptionPoco> companyJobDescriptions = _companyJobDescriptionLogic.GetAll();

            if (companyJobDescriptions == null || companyJobDescriptions.Count == 0)
            {
                return NotFound("No company job descriptions found.");
            }

            return Ok(companyJobDescriptions);
        }

        // GET: api/CompanyJobDescription/{id}
        // Get a specific company job description by id
        [HttpGet("{id}")]
        public ActionResult GetCompanyJobsDescription(Guid id)
        {
            CompanyJobDescriptionPoco companyJobsDescription = _companyJobDescriptionLogic.Get(id);

            if (companyJobsDescription == null)
            {
                return NotFound($"Company Job Description with id {id} not found.");
            }

            return Ok(companyJobsDescription);
        }

        // POST: api/CompanyJobDescription
        // Create a new company job description
        [HttpPost]
        public ActionResult CreateCompanyJobDescription([FromBody] CompanyJobDescriptionPoco companyJobDescription)
        {
            if (companyJobDescription == null)
            {
                return BadRequest("Company job description cannot be null.");
            }

            // Call the business logic to add the new company job description
            _companyJobDescriptionLogic.Add(companyJobDescription);

            return CreatedAtAction(nameof(GetCompanyJobsDescription), new { id = companyJobDescription.Id }, companyJobDescription);
        }

        // PUT: api/CompanyJobDescription/{id}
        // Update an existing company job description by id
        [HttpPut("{id}")]
        public ActionResult UpdateCompanyJobDescription(Guid id, [FromBody] CompanyJobDescriptionPoco companyJobDescription)
        {
            if (companyJobDescription == null || companyJobDescription.Id != id)
            {
                return BadRequest("Invalid company job description data.");
            }

            // Ensure the company job description exists
            var existingCompanyJobDescription = _companyJobDescriptionLogic.Get(id);
            if (existingCompanyJobDescription == null)
            {
                return NotFound($"Company Job Description with id {id} not found.");
            }

            // Call the business logic to update the company job description
            _companyJobDescriptionLogic.Update(companyJobDescription);

            return NoContent(); // Successfully updated
        }

        // DELETE: api/CompanyJobDescription/{id}
        // Delete a company job description by id
        [HttpDelete("{id}")]
        public ActionResult DeleteCompanyJobDescription(Guid id)
        {
            // Ensure the company job description exists before attempting to delete
            var companyJobDescription = _companyJobDescriptionLogic.Get(id);
            if (companyJobDescription == null)
            {
                return NotFound($"Company Job Description with id {id} not found.");
            }

            // Call the business logic to delete the company job description
            _companyJobDescriptionLogic.Delete(id);

            return NoContent(); // Successfully deleted
        }

        public ActionResult PostCompanyJobsDescription(CompanyJobDescriptionPoco[] companyJobDescriptionPocos)
        {
            throw new NotImplementedException();
        }

        public ActionResult DeleteCompanyJobsDescription(CompanyJobDescriptionPoco[] companyJobDescriptionPocos)
        {
            throw new NotImplementedException();
        }

        public ActionResult PutCompanyJobsDescription(CompanyJobDescriptionPoco[] companyJobDescriptionPocos)
        {
            throw new NotImplementedException();
        }
    }
}
