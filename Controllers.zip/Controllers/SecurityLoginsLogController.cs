﻿using CareerCloud.BusinessLogicLayer;
using CareerCloud.Pocos;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;

namespace CareerCloud.Controllers
{
    [Route("api/careercloud/security/loginslog/v1")]
    [ApiController]
    public class SecurityLoginsLogController : ControllerBase
    {
        private readonly SecurityLoginsLogLogic _securityLoginsLogLogic;

        // Constructor for dependency injection of the business logic layer
        public SecurityLoginsLogController(SecurityLoginsLogLogic securityLoginsLogLogic)
        {
            _securityLoginsLogLogic = securityLoginsLogLogic;
        }

        public SecurityLoginsLogController()
        {
        }

        // GET: api/SecurityLoginsLog
        // Get all login logs
        [HttpGet]
        public IActionResult GetAllSecurityLoginsLogs()
        {
            List<SecurityLoginsLogPoco> securityLoginsLogs = _securityLoginsLogLogic.GetAll();

            if (securityLoginsLogs == null || securityLoginsLogs.Count == 0)
            {
                return NotFound("No login logs found.");
            }

            return Ok(securityLoginsLogs);
        }

        // GET: api/SecurityLoginsLog/{id}
        // Get a specific login log by id
        [HttpGet("{id}")]
        public IActionResult GetSecurityLoginsLog(Guid id)
        {
            SecurityLoginsLogPoco securityLoginsLog = _securityLoginsLogLogic.Get(id);

            if (securityLoginsLog == null)
            {
                return NotFound($"Login log with id {id} not found.");
            }

            return Ok(securityLoginsLog);
        }

        // POST: api/SecurityLoginsLog
        // Create a new login log
        [HttpPost]
        public IActionResult CreateSecurityLoginsLog([FromBody] SecurityLoginsLogPoco securityLoginsLog)
        {
            if (securityLoginsLog == null)
            {
                return BadRequest("Login log cannot be null.");
            }

            // Call the business logic to add the new login log
            _securityLoginsLogLogic.Add(securityLoginsLog);

            return CreatedAtAction(nameof(GetSecurityLoginsLog), new { id = securityLoginsLog.Id }, securityLoginsLog);
        }

        // PUT: api/SecurityLoginsLog/{id}
        // Update an existing login log by id
        [HttpPut("{id}")]
        public IActionResult UpdateSecurityLoginsLog(Guid id, [FromBody] SecurityLoginsLogPoco securityLoginsLog)
        {
            if (securityLoginsLog == null || securityLoginsLog.Id != id)
            {
                return BadRequest("Invalid login log data.");
            }

            // Ensure the login log exists
            var existingSecurityLoginsLog = _securityLoginsLogLogic.Get(id);
            if (existingSecurityLoginsLog == null)
            {
                return NotFound($"Login log with id {id} not found.");
            }

            // Call the business logic to update the login log
            _securityLoginsLogLogic.Update(securityLoginsLog);

            return NoContent(); // Successfully updated
        }

        // DELETE: api/SecurityLoginsLog/{id}
        // Delete a login log by id
        [HttpDelete("{id}")]
        public IActionResult DeleteSecurityLoginsLog(Guid id)
        {
            // Ensure the login log exists before attempting to delete
            var securityLoginsLog = _securityLoginsLogLogic.Get(id);
            if (securityLoginsLog == null)
            {
                return NotFound($"Login log with id {id} not found.");
            }

            // Call the business logic to delete the login log
            _securityLoginsLogLogic.Delete(id);

            return NoContent(); // Successfully deleted
        }

        public ActionResult PostSecurityLoginLog(SecurityLoginsLogPoco[] securityLoginsLogPocos)
        {
            throw new NotImplementedException();
        }

        public ActionResult PutSecurityLoginLog(SecurityLoginsLogPoco[] securityLoginsLogPocos)
        {
            throw new NotImplementedException();
        }

        public ActionResult DeleteSecurityLoginLog(SecurityLoginsLogPoco[] securityLoginsLogPocos)
        {
            throw new NotImplementedException();
        }

        public ActionResult GetSecurityLoginLog(Guid id)
        {
            throw new NotImplementedException();
        }
    }
}
