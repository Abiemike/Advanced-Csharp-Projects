﻿using CareerCloud.BusinessLogicLayer;
using CareerCloud.Pocos;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;

namespace CareerCloud.Controllers
{
    [Route("api/careercloud/security/role/v1")]
    [ApiController]
    public class SecurityRoleController : ControllerBase
    {
        private readonly SecurityRoleLogic _securityRoleLogic;

        // Constructor for dependency injection
        public SecurityRoleController(SecurityRoleLogic securityRoleLogic)
        {
            _securityRoleLogic = securityRoleLogic ?? throw new ArgumentNullException(nameof(securityRoleLogic));
        }

        public SecurityRoleController()
        {
        }

        // GET: api/careercloud/security/role/v1
        [HttpGet]
        public IActionResult GetAllSecurityRoles()
        {
            List<SecurityRolePoco> securityRoles = _securityRoleLogic.GetAll();

            if (securityRoles == null || securityRoles.Count == 0)
            {
                return NotFound("No security roles found.");
            }

            return Ok(securityRoles);
        }

        // GET: api/careercloud/security/role/v1/{id}
        [HttpGet("{id}")]
        public IActionResult GetSecurityRole(Guid id)
        {
            SecurityRolePoco securityRole = _securityRoleLogic.Get(id);

            if (securityRole == null)
            {
                return NotFound($"Security Role with id {id} not found.");
            }

            return Ok(securityRole);
        }

        // POST: api/careercloud/security/role/v1
        [HttpPost]
        public IActionResult CreateSecurityRole([FromBody] SecurityRolePoco securityRole)
        {
            if (securityRole == null)
            {
                return BadRequest("Security Role cannot be null.");
            }

            // Pass the security role as an array
            _securityRoleLogic.Add(new SecurityRolePoco[] { securityRole });

            return CreatedAtAction(nameof(GetSecurityRole), new { id = securityRole.Id }, securityRole);
        }

        // PUT: api/careercloud/security/role/v1/{id}
        [HttpPut("{id}")]
        public IActionResult UpdateSecurityRole(Guid id, [FromBody] SecurityRolePoco securityRole)
        {
            if (securityRole == null || securityRole.Id != id)
            {
                return BadRequest("Invalid security role data.");
            }

            var existingSecurityRole = _securityRoleLogic.Get(id);
            if (existingSecurityRole == null)
            {
                return NotFound($"Security Role with id {id} not found.");
            }

            // Pass the security role as an array
            _securityRoleLogic.Update(new SecurityRolePoco[] { securityRole });

            return NoContent(); // Successfully updated
        }

        // DELETE: api/careercloud/security/role/v1/{id}
        [HttpDelete("{id}")]
        public IActionResult DeleteSecurityRole(Guid id)
        {
            var securityRole = _securityRoleLogic.Get(id);
            if (securityRole == null)
            {
                return NotFound($"Security Role with id {id} not found.");
            }

            _securityRoleLogic.Delete(id);

            return NoContent(); // Successfully deleted
        }

        public ActionResult PutSecurityRole(SecurityRolePoco[] securityRolePocos)
        {
            throw new NotImplementedException();
        }

        public ActionResult DeleteSecurityRole(SecurityRolePoco[] securityRolePocos)
        {
            throw new NotImplementedException();
        }

        public ActionResult PostSecurityRole(SecurityRolePoco[] securityRolePocos)
        {
            throw new NotImplementedException();
        }
    }
}
