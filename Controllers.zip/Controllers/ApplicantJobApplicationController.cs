﻿using CareerCloud.BusinessLogicLayer;
using CareerCloud.Pocos;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;

namespace CareerCloud.Controllers
{
    [Route("api/careercloud/applicant/jobapplication/v1")]
    [ApiController]
    public class ApplicantJobApplicationController : ControllerBase
    {
        private readonly ApplicantJobApplicationLogic _applicantJobApplicationLogic;

        // Constructor for dependency injection of the business logic layer
        public ApplicantJobApplicationController(ApplicantJobApplicationLogic applicantJobApplicationLogic)
        {
            _applicantJobApplicationLogic = applicantJobApplicationLogic;
        }

        public ApplicantJobApplicationController()
        {
        }

        // GET: api/ApplicantJobApplication
        // Get all applicant job applications
        [HttpGet]
        public IActionResult GetAllApplicantJobApplications()
        {
            List<ApplicantJobApplicationPoco> applicantJobApplications = _applicantJobApplicationLogic.GetAll();

            if (applicantJobApplications == null || applicantJobApplications.Count == 0)
            {
                return NotFound("No applicant job applications found.");
            }

            return Ok(applicantJobApplications);
        }

        // GET: api/ApplicantJobApplication/{id}
        // Get a specific applicant job application by id
        [HttpGet("{id}")]
        public IActionResult GetApplicantJobApplication(Guid id)
        {
            ApplicantJobApplicationPoco applicantJobApplication = _applicantJobApplicationLogic.Get(id);

            if (applicantJobApplication == null)
            {
                return NotFound($"Applicant Job Application with id {id} not found.");
            }

            return Ok(applicantJobApplication);
        }

        // POST: api/ApplicantJobApplication
        // Create a new applicant job application
        [HttpPost]
        public IActionResult CreateApplicantJobApplication([FromBody] ApplicantJobApplicationPoco applicantJobApplication)
        {
            if (applicantJobApplication == null)
            {
                return BadRequest("Applicant job application cannot be null.");
            }

            // Call the business logic to add the new applicant job application
            _applicantJobApplicationLogic.Add(applicantJobApplication);

            return CreatedAtAction(nameof(GetApplicantJobApplication), new { id = applicantJobApplication.Id }, applicantJobApplication);
        }

        // PUT: api/ApplicantJobApplication/{id}
        // Update an existing applicant job application by id
        [HttpPut("{id}")]
        public IActionResult UpdateApplicantJobApplication(Guid id, [FromBody] ApplicantJobApplicationPoco applicantJobApplication)
        {
            if (applicantJobApplication == null || applicantJobApplication.Id != id)
            {
                return BadRequest("Invalid applicant job application data.");
            }

            // Ensure the applicant job application exists
            var existingApplicantJobApplication = _applicantJobApplicationLogic.Get(id);
            if (existingApplicantJobApplication == null)
            {
                return NotFound($"Applicant Job Application with id {id} not found.");
            }

            // Call the business logic to update the applicant job application
            _applicantJobApplicationLogic.Update(applicantJobApplication);

            return NoContent(); // Successfully updated
        }

        // DELETE: api/ApplicantJobApplication/{id}
        // Delete an applicant job application by id
        [HttpDelete("{id}")]
        public IActionResult DeleteApplicantJobApplication(Guid id)
        {
            // Ensure the applicant job application exists before attempting to delete
            var applicantJobApplication = _applicantJobApplicationLogic.Get(id);
            if (applicantJobApplication == null)
            {
                return NotFound($"Applicant Job Application with id {id} not found.");
            }

            // Call the business logic to delete the applicant job application
            _applicantJobApplicationLogic.Delete(id);

            return NoContent(); // Successfully deleted
        }

        public ActionResult PutApplicantJobApplication(ApplicantJobApplicationPoco[] applicantJobApplicationPocos)
        {
            throw new NotImplementedException();
        }

        public ActionResult PostApplicantJobApplication(ApplicantJobApplicationPoco[] applicantJobApplicationPocos)
        {
            throw new NotImplementedException();
        }

        public ActionResult DeleteApplicantJobApplication(ApplicantJobApplicationPoco[] applicantJobApplicationPocos)
        {
            throw new NotImplementedException();
        }
    }
}
