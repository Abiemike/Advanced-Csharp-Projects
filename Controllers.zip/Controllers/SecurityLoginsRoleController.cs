﻿using CareerCloud.BusinessLogicLayer;
using CareerCloud.Pocos;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;

namespace CareerCloud.Controllers
{
    [Route("api/careercloud/security/loginsrole/v1")]
    [ApiController]
    public class SecurityLoginsRoleController : ControllerBase
    {
        private readonly SecurityLoginsRoleLogic _securityLoginsRoleLogic;

        // Constructor for dependency injection of the business logic layer
        public SecurityLoginsRoleController(SecurityLoginsRoleLogic securityLoginsRoleLogic)
        {
           // _securityLoginsRoleLogic = securityLoginsRoleLogic;
            _securityLoginsRoleLogic = securityLoginsRoleLogic ?? throw new ArgumentNullException(nameof(securityLoginsRoleLogic));

        }

        public SecurityLoginsRoleController()
        {
        }

        // GET: api/SecurityLoginsRole
        // Get all security logins roles
        [HttpGet]
        public IActionResult GetAllSecurityLoginsRoles()
        {
            List<SecurityLoginsRolePoco> securityLoginsRoles = _securityLoginsRoleLogic.GetAll();

            if (securityLoginsRoles == null || securityLoginsRoles.Count == 0)
            {
                return NotFound("No security logins roles found.");
            }

            return Ok(securityLoginsRoles);
        }

        // GET: api/SecurityLoginsRole/{id}
        // Get a specific security login role by id
        [HttpGet("{id}")]
        public IActionResult GetSecurityLoginsRole(Guid id)
        {
            SecurityLoginsRolePoco securityLoginsRole = _securityLoginsRoleLogic.Get(id);

            if (securityLoginsRole == null)
            {
                return NotFound($"Security Login Role with id {id} not found.");
            }

            return Ok(securityLoginsRole);
        }

        // POST: api/SecurityLoginsRole
        // Create a new security login role
        [HttpPost]
        public IActionResult CreateSecurityLoginsRole([FromBody] SecurityLoginsRolePoco securityLoginsRole)
        {
            if (securityLoginsRole == null)
            {
                return BadRequest("Security Login Role cannot be null.");
            }

            // Call the business logic to add the new security login role
            _securityLoginsRoleLogic.Add(securityLoginsRole);

            return CreatedAtAction(nameof(GetSecurityLoginsRole), new { id = securityLoginsRole.Id }, securityLoginsRole);
        }

        // PUT: api/SecurityLoginsRole/{id}
        // Update an existing security login role by id
        [HttpPut("{id}")]
        public IActionResult UpdateSecurityLoginsRole(Guid id, [FromBody] SecurityLoginsRolePoco securityLoginsRole)
        {
            if (securityLoginsRole == null || securityLoginsRole.Id != id)
            {
                return BadRequest("Invalid security login role data.");
            }

            // Ensure the security login role exists
            var existingSecurityLoginsRole = _securityLoginsRoleLogic.Get(id);
            if (existingSecurityLoginsRole == null)
            {
                return NotFound($"Security Login Role with id {id} not found.");
            }

            // Call the business logic to update the security login role
            _securityLoginsRoleLogic.Update(securityLoginsRole);

            return NoContent(); // Successfully updated
        }

        // DELETE: api/SecurityLoginsRole/{id}
        // Delete a security login role by id
        [HttpDelete("{id}")]
        public IActionResult DeleteSecurityLoginsRole(Guid id)
        {
            // Ensure the security login role exists before attempting to delete
            var securityLoginsRole = _securityLoginsRoleLogic.Get(id);
            if (securityLoginsRole == null)
            {
                return NotFound($"Security Login Role with id {id} not found.");
            }

            // Call the business logic to delete the security login role
            _securityLoginsRoleLogic.Delete(id);

            return NoContent(); // Successfully deleted
        }

        public ActionResult PostSecurityLoginRole(SecurityLoginsRolePoco[] securityLoginsRolePocos)
        {
            throw new NotImplementedException();
        }

        public ActionResult DeleteSecurityLoginRole(SecurityLoginsRolePoco[] securityLoginsRolePocos)
        {
            throw new NotImplementedException();
        }
    }
}
