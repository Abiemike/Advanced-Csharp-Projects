﻿using CareerCloud.BusinessLogicLayer;
using CareerCloud.Pocos;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace CareerCloud.Controllers
{
    [Route("api/careercloud/system/countrycode/v1")]
    [ApiController]
    public class SystemCountryCodeController : ControllerBase
    {
        private readonly SystemCountryCodeLogic _systemCountryCodeLogic;

        // Constructor for dependency injection of the business logic layer
        public SystemCountryCodeController(SystemCountryCodeLogic systemCountryCodeLogic)
        {
            _systemCountryCodeLogic = systemCountryCodeLogic;
        }

        public SystemCountryCodeController()
        {
        }

        // GET: api/SystemCountryCode
        [HttpGet]
        public IActionResult GetAllSystemCountryCodes()
        {
            List<SystemCountryCodePoco> systemCountryCodes = _systemCountryCodeLogic.GetAll();

            if (systemCountryCodes == null || systemCountryCodes.Count == 0)
            {
                return NotFound("No system country codes found.");
            }

            return Ok(systemCountryCodes);
        }

        // GET: api/SystemCountryCode/{id}
        [HttpGet("{id}")]
        public IActionResult GetSystemCountryCode(string code)
        {
            SystemCountryCodePoco systemCountryCode = _systemCountryCodeLogic.Get(code);

            if (systemCountryCode == null)
            {
                return NotFound($"System Country Code with id {code} not found.");
            }

            return Ok(systemCountryCode);
        }

        // POST: api/SystemCountryCode
        [HttpPost]
        public IActionResult CreateSystemCountryCode([FromBody] SystemCountryCodePoco systemCountryCode)
        {
            if (systemCountryCode == null)
            {
                return BadRequest("System Country Code cannot be null.");
            }

            _systemCountryCodeLogic.Add(systemCountryCode);

            return CreatedAtAction(nameof(GetSystemCountryCode), new { code = systemCountryCode.Code }, systemCountryCode);
        }

        // PUT: api/SystemCountryCode/{id}
        [HttpPut("{code}")]
        public IActionResult UpdateSystemCountryCode(string code, [FromBody] SystemCountryCodePoco systemCountryCode)
        {
            if (systemCountryCode == null || systemCountryCode.Code != code)
            {
                return BadRequest("Invalid system country code data.");
            }

            // Ensure the system country code exists
            var existingCountryCode = _systemCountryCodeLogic.Get(code);
            if (existingCountryCode == null)
            {
                return NotFound($"System Country Code with id {code} not found.");
            }

            // Call the business logic to update the system country code
            _systemCountryCodeLogic.Update(systemCountryCode); // No need for bool success here

            return NoContent(); // Successfully updated
        }


        // DELETE: api/SystemCountryCode/{id}
        [HttpDelete("{code}")]
        public IActionResult DeleteSystemCountryCode(string code)  // Keep as string
        {
            // Ensure the system country code exists before attempting to delete
            var systemCountryCode = _systemCountryCodeLogic.Get(code);  // Pass string 'code' directly to the logic layer
            if (systemCountryCode == null)
            {
                return NotFound($"System Country Code with code {code} not found.");
            }

            // Call the business logic to delete the system country code
            _systemCountryCodeLogic.Delete(code);  // Pass string 'code' directly to the logic layer

            return NoContent(); // Successfully deleted
        }

        public ActionResult PutSystemCountryCode(SystemCountryCodePoco[] systemCountryCodePocos)
        {
            throw new NotImplementedException();
        }

        public ActionResult PostSystemCountryCode(SystemCountryCodePoco[] systemCountryCodePocos)
        {
            throw new NotImplementedException();
        }

        public ActionResult DeleteSystemCountryCode(SystemCountryCodePoco[] systemCountryCodePocos)
        {
            throw new NotImplementedException();
        }
    }
}
