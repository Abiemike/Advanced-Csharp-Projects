﻿using CareerCloud.BusinessLogicLayer;
using CareerCloud.Pocos;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;

namespace CareerCloud.Controllers
{
    [Route("api/careercloud/applicant/skill/v1")]
    [ApiController]
    public class ApplicantSkillController : ControllerBase
    {
        private readonly ApplicantSkillLogic _applicantSkillLogic;

        // Constructor for dependency injection of the business logic layer
        public ApplicantSkillController(ApplicantSkillLogic applicantSkillLogic)
        {
            _applicantSkillLogic = applicantSkillLogic;
        }

        public ApplicantSkillController()
        {
        }

        // GET: api/ApplicantSkill
        // Get all applicant skills
        [HttpGet]
        public IActionResult GetAllApplicantSkills()
        {
            List<ApplicantSkillPoco> applicantSkills = _applicantSkillLogic.GetAll();

            if (applicantSkills == null || applicantSkills.Count == 0)
            {
                return NotFound("No applicant skills found.");
            }

            return Ok(applicantSkills);
        }

        // GET: api/ApplicantSkill/{id}
        // Get a specific applicant skill by id
        [HttpGet("{id}")]
        public IActionResult GetApplicantSkill(Guid id)
        {
            ApplicantSkillPoco applicantSkill = _applicantSkillLogic.Get(id);

            if (applicantSkill == null)
            {
                return NotFound($"Applicant Skill with id {id} not found.");
            }

            return Ok(applicantSkill);
        }

        // POST: api/ApplicantSkill
        // Create a new applicant skill
        [HttpPost]
        public IActionResult CreateApplicantSkill([FromBody] ApplicantSkillPoco applicantSkill)
        {
            if (applicantSkill == null)
            {
                return BadRequest("Applicant skill cannot be null.");
            }

            // Call the business logic to add the new applicant skill
            _applicantSkillLogic.Add(applicantSkill);

            return CreatedAtAction(nameof(GetApplicantSkill), new { id = applicantSkill.Id }, applicantSkill);
        }

        // PUT: api/ApplicantSkill/{id}
        // Update an existing applicant skill by id
        [HttpPut("{id}")]
        public IActionResult UpdateApplicantSkill(Guid id, [FromBody] ApplicantSkillPoco applicantSkill)
        {
            if (applicantSkill == null || applicantSkill.Id != id)
            {
                return BadRequest("Invalid applicant skill data.");
            }

            // Ensure the applicant skill exists
            var existingApplicantSkill = _applicantSkillLogic.Get(id);
            if (existingApplicantSkill == null)
            {
                return NotFound($"Applicant Skill with id {id} not found.");
            }

            // Call the business logic to update the applicant skill
            _applicantSkillLogic.Update(applicantSkill);

            return NoContent(); // Successfully updated
        }

        // DELETE: api/ApplicantSkill/{id}
        // Delete an applicant skill by id
        [HttpDelete("{id}")]
        public IActionResult DeleteApplicantSkill(Guid id)
        {
            // Ensure the applicant skill exists before attempting to delete
            var applicantSkill = _applicantSkillLogic.Get(id);
            if (applicantSkill == null)
            {
                return NotFound($"Applicant Skill with id {id} not found.");
            }

            // Call the business logic to delete the applicant skill
            _applicantSkillLogic.Delete(id);

            return NoContent(); // Successfully deleted
        }

        public ActionResult PutApplicantSkill(ApplicantSkillPoco[] applicantSkillPocos)
        {
            throw new NotImplementedException();
        }

        public ActionResult PostApplicantSkill(ApplicantSkillPoco[] applicantSkillPocos)
        {
            throw new NotImplementedException();
        }

        public ActionResult DeleteApplicantSkill(ApplicantSkillPoco[] applicantSkillPocos)
        {
            throw new NotImplementedException();
        }
    }
}
