﻿using CareerCloud.BusinessLogicLayer;
using CareerCloud.Pocos;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;

namespace CareerCloud.Controllers
{
    [Route("api/careercloud/system/languagecode/v1")]
    [ApiController]
    public class SystemLanguageCodeController : ControllerBase
    {
        private readonly SystemLanguageCodeLogic _systemLanguageCodeLogic;

        // Constructor to inject the SystemLanguageCodeLogic
        public SystemLanguageCodeController(SystemLanguageCodeLogic systemLanguageCodeLogic)
        {
            _systemLanguageCodeLogic = systemLanguageCodeLogic;
        }

        public SystemLanguageCodeController()
        {
        }

        // GET: api/SystemLanguageCode
        [HttpGet]
        public IActionResult GetAllSystemLanguageCodes()
        {
            IList<SystemLanguageCodePoco> systemLanguageCodes = _systemLanguageCodeLogic.GetAll();

            if (systemLanguageCodes == null || systemLanguageCodes.Count == 0)
            {
                return NotFound("No system language codes found.");
            }

            return Ok(systemLanguageCodes);
        }

        // GET: api/SystemLanguageCode/{id}
        [HttpGet("{id}")]
        public IActionResult GetSystemLanguageCode(string id)
        {
            SystemLanguageCodePoco systemLanguageCode = _systemLanguageCodeLogic.Get(id);

            if (systemLanguageCode == null)
            {
                return NotFound($"System Language Code with id {id} not found.");
            }

            return Ok(systemLanguageCode);
        }

        // POST: api/SystemLanguageCode
        [HttpPost]
        public IActionResult CreateSystemLanguageCode([FromBody] SystemLanguageCodePoco systemLanguageCode)
        {
            if (systemLanguageCode == null)
            {
                return BadRequest("System language code cannot be null.");
            }

            _systemLanguageCodeLogic.Add(systemLanguageCode);

            return CreatedAtAction(nameof(GetSystemLanguageCode), new { id = systemLanguageCode.LanguageID }, systemLanguageCode);
        }

        // PUT: api/SystemLanguageCode/{id}
        [HttpPut("{id}")]
        public IActionResult UpdateSystemLanguageCode(string id, [FromBody] SystemLanguageCodePoco systemLanguageCode)
        {
            if (systemLanguageCode == null || systemLanguageCode.LanguageID != id)
            {
                return BadRequest("Invalid system language code data.");
            }

            var existingSystemLanguageCode = _systemLanguageCodeLogic.Get(id);
            if (existingSystemLanguageCode == null)
            {
                return NotFound($"System Language Code with id {id} not found.");
            }

            _systemLanguageCodeLogic.Update(systemLanguageCode);

            return NoContent();
        }

        // DELETE: api/SystemLanguageCode/{id}
        [HttpDelete]
        public IActionResult DeleteSystemLanguageCode(string LanguageID)
        {
            var systemLanguageCode = _systemLanguageCodeLogic.Get(LanguageID);
            if (systemLanguageCode == null)
            {
                return NotFound($"System Language Code with id {LanguageID} not found.");
            }

            _systemLanguageCodeLogic.Delete(LanguageID);

            return NoContent();
        }

        public ActionResult GetSystemLanguageCode(SystemLanguageCodePoco[] systemLanguageCodePocos)
        {
            throw new NotImplementedException();
        }

        public IActionResult DeleteSystemLanguageCode(SystemLanguageCodePoco[] systemLanguageCodePocos)
        {
            throw new NotImplementedException();
        }

        public ActionResult PostSystemLanguageCode(SystemLanguageCodePoco[] systemLanguageCodePocos)
        {
            throw new NotImplementedException();
        }
    }
}
