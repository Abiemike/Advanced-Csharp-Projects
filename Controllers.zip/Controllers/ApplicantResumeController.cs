﻿using CareerCloud.BusinessLogicLayer;
using CareerCloud.Pocos;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;

namespace CareerCloud.Controllers
{
    [Route("api/careercloud/applicant/resume/v1")]
    [ApiController]
    public class ApplicantResumeController : ControllerBase
    {
        private readonly ApplicantResumeLogic _applicantResumeLogic;

        // Constructor for dependency injection of the business logic layer
        public ApplicantResumeController(ApplicantResumeLogic applicantResumeLogic)
        {
            _applicantResumeLogic = applicantResumeLogic;
        }

        public ApplicantResumeController()
        {
        }

        // GET: api/ApplicantResume
        // Get all applicant resumes
        [HttpGet]
        public IActionResult GetAllApplicantResumes()
        {
            List<ApplicantResumePoco> applicantResumes = _applicantResumeLogic.GetAll();

            if (applicantResumes == null || applicantResumes.Count == 0)
            {
                return NotFound("No applicant resumes found.");
            }

            return Ok(applicantResumes);
        }

        // GET: api/ApplicantResume/{id}
        // Get a specific applicant resume by id
        [HttpGet("{id}")]
        public IActionResult GetApplicantResume(Guid id)
        {
            ApplicantResumePoco applicantResume = _applicantResumeLogic.Get(id);

            if (applicantResume == null)
            {
                return NotFound($"Applicant Resume with id {id} not found.");
            }

            return Ok(applicantResume);
        }

        // POST: api/ApplicantResume
        // Create a new applicant resume
        [HttpPost]
        public IActionResult CreateApplicantResume([FromBody] ApplicantResumePoco applicantResume)
        {
            if (applicantResume == null)
            {
                return BadRequest("Applicant resume cannot be null.");
            }

            // Call the business logic to add the new applicant resume
            _applicantResumeLogic.Add(applicantResume);

            return CreatedAtAction(nameof(GetApplicantResume), new { id = applicantResume.Id }, applicantResume);
        }

        // PUT: api/ApplicantResume/{id}
        // Update an existing applicant resume by id
        [HttpPut("{id}")]
        public IActionResult UpdateApplicantResume(Guid id, [FromBody] ApplicantResumePoco applicantResume)
        {
            if (applicantResume == null || applicantResume.Id != id)
            {
                return BadRequest("Invalid applicant resume data.");
            }

            // Ensure the applicant resume exists
            var existingApplicantResume = _applicantResumeLogic.Get(id);
            if (existingApplicantResume == null)
            {
                return NotFound($"Applicant Resume with id {id} not found.");
            }

            // Call the business logic to update the applicant resume
            _applicantResumeLogic.Update(applicantResume);

            return NoContent(); // Successfully updated
        }

        // DELETE: api/ApplicantResume/{id}
        // Delete an applicant resume by id
        [HttpDelete("{id}")]
        public IActionResult DeleteApplicantResume(Guid id)
        {
            // Ensure the applicant resume exists before attempting to delete
            var applicantResume = _applicantResumeLogic.Get(id);
            if (applicantResume == null)
            {
                return NotFound($"Applicant Resume with id {id} not found.");
            }

            // Call the business logic to delete the applicant resume
            _applicantResumeLogic.Delete(id);

            return NoContent(); // Successfully deleted
        }

        public ActionResult PutApplicantResume(ApplicantResumePoco[] applicantResumePocos)
        {
            throw new NotImplementedException();
        }

        public ActionResult PostApplicantResume(ApplicantResumePoco[] applicantResumePocos)
        {
            throw new NotImplementedException();
        }

        public ActionResult DeleteApplicantResume(ApplicantResumePoco[] applicantResumePocos)
        {
            throw new NotImplementedException();
        }
    }
}
