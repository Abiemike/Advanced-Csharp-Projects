﻿using CareerCloud.BusinessLogicLayer;
using CareerCloud.Pocos;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;

namespace CareerCloud.Controllers
{
    [Route("api/careercloud/company/profile/v1")]
    [ApiController]
    public class CompanyProfileController : ControllerBase
    {
        private readonly CompanyProfileLogic _companyProfileLogic;

        // Constructor for dependency injection of the business logic layer
        public CompanyProfileController(CompanyProfileLogic companyProfileLogic)
        {
            _companyProfileLogic = companyProfileLogic ?? throw new ArgumentNullException(nameof(companyProfileLogic));
        }

        public CompanyProfileController()
        {
        }

        // GET: api/CompanyProfile
        // Get all company profiles
        [HttpGet]
        public IActionResult GetAllCompanyProfiles()
        {
            List<CompanyProfilePoco> companyProfiles = _companyProfileLogic.GetAll();

            if (companyProfiles == null || companyProfiles.Count == 0)
            {
                return NotFound("No company profiles found.");
            }

            return Ok(companyProfiles);
        }

        // GET: api/CompanyProfile/{id}
        // Get a specific company profile by id
        [HttpGet("{id}")]
        public IActionResult GetCompanyProfile(Guid id)
        {
            CompanyProfilePoco companyProfile = _companyProfileLogic.Get(id);

            if (companyProfile == null)
            {
                return NotFound($"Company Profile with id {id} not found.");
            }

            return Ok(companyProfile);
        }

        // POST: api/CompanyProfile
        // Create a new company profile
        [HttpPost]
        public IActionResult CreateCompanyProfile([FromBody] CompanyProfilePoco companyProfile)
        {
            if (companyProfile == null)
            {
                return BadRequest("Company profile cannot be null.");
            }

            // Call the business logic to add the new company profile
            _companyProfileLogic.Add(companyProfile);

            return CreatedAtAction(nameof(GetCompanyProfile), new { id = companyProfile.Id }, companyProfile);
        }

        // PUT: api/CompanyProfile/{id}
        // Update an existing company profile by id
        [HttpPut("{id}")]
        public IActionResult UpdateCompanyProfile(Guid id, [FromBody] CompanyProfilePoco companyProfile)
        {
            if (companyProfile == null || companyProfile.Id != id)
            {
                return BadRequest("Invalid company profile data.");
            }

            // Ensure the company profile exists
            var existingCompanyProfile = _companyProfileLogic.Get(id);
            if (existingCompanyProfile == null)
            {
                return NotFound($"Company Profile with id {id} not found.");
            }

            // Call the business logic to update the company profile
            _companyProfileLogic.Update(companyProfile);

            return NoContent(); // Successfully updated
        }

        // DELETE: api/CompanyProfile/{id}
        // Delete a company profile by id
        [HttpDelete("{id}")]
        public IActionResult DeleteCompanyProfile(Guid id)
        {
            // Ensure the company profile exists before attempting to delete
            var companyProfile = _companyProfileLogic.Get(id);
            if (companyProfile == null)
            {
                return NotFound($"Company Profile with id {id} not found.");
            }

            // Call the business logic to delete the company profile
            _companyProfileLogic.Delete(id);

            return NoContent(); // Successfully deleted
        }

        public IActionResult DeleteCompanyProfile(CompanyProfilePoco[] companyProfilePocos)
        {
            throw new NotImplementedException();
        }

        public ActionResult PostCompanyProfile(CompanyProfilePoco[] companyProfilePocos)
        {
            throw new NotImplementedException();
        }

        public ActionResult PutCompanyProfile(CompanyProfilePoco[] companyProfilePocos)
        {
            throw new NotImplementedException();
        }
    }
}
