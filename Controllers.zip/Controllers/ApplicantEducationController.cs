﻿using CareerCloud.BusinessLogicLayer;
using CareerCloud.Pocos;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;

namespace CareerCloud.Controllers
{
    [Route("api/careercloud/applicant/education/v1")]
    [ApiController]
    public class ApplicantEducationController : ControllerBase
    {
        private readonly ApplicantEducationLogic _applicantEducationLogic;

        // Constructor for dependency injection of the business logic layer
        public ApplicantEducationController(ApplicantEducationLogic applicantEducationLogic)
        {
            _applicantEducationLogic = applicantEducationLogic;
        }

        public ApplicantEducationController()
        {
        }

        // GET: api/ApplicantEducation
        // Get all applicant education records
        [HttpGet]
        public IActionResult GetAllApplicantEducation()
        {
            List<ApplicantEducationPoco> applicantEducations = _applicantEducationLogic.GetAll();

            if (applicantEducations == null || applicantEducations.Count == 0)
            {
                return NotFound("No applicant education records found.");
            }

            return Ok(applicantEducations);
        }

        // GET: api/ApplicantEducation/{id}
        // Get a specific applicant education record by id
        [HttpGet("{id}")]
        public IActionResult GetApplicantEducation(Guid id)
        {
            ApplicantEducationPoco applicantEducation = _applicantEducationLogic.Get(id);

            if (applicantEducation == null)
            {
                return NotFound($"Applicant Education with id {id} not found.");
            }

            return Ok(applicantEducation);
        }

        // POST: api/ApplicantEducation
        // Create a new applicant education record
        [HttpPost]
        public IActionResult CreateApplicantEducation([FromBody] ApplicantEducationPoco applicantEducation)
        {
            if (applicantEducation == null)
            {
                return BadRequest("Applicant education cannot be null.");
            }

            // Call the business logic to add the new applicant education record
            _applicantEducationLogic.Add(applicantEducation);

            return CreatedAtAction(nameof(GetApplicantEducation), new { id = applicantEducation.Id }, applicantEducation);
        }

        // PUT: api/ApplicantEducation/{id}
        // Update an existing applicant education record by id
        [HttpPut("{id}")]
        public IActionResult UpdateApplicantEducation(Guid id, [FromBody] ApplicantEducationPoco applicantEducation)
        {
            if (applicantEducation == null || applicantEducation.Id != id)
            {
                return BadRequest("Invalid applicant education data.");
            }

            // Ensure the applicant education exists
            var existingApplicantEducation = _applicantEducationLogic.Get(id);
            if (existingApplicantEducation == null)
            {
                return NotFound($"Applicant Education with id {id} not found.");
            }

            // Call the business logic to update the applicant education record
            _applicantEducationLogic.Update(applicantEducation);

            return NoContent(); // Successfully updated
        }

        // DELETE: api/ApplicantEducation/{id}
        // Delete an applicant education record by id
        [HttpDelete("{id}")]
        public IActionResult DeleteApplicantEducation(Guid id)
        {
            // Ensure the applicant education exists before attempting to delete
            var applicantEducation = _applicantEducationLogic.Get(id);
            if (applicantEducation == null)
            {
                return NotFound($"Applicant Education with id {id} not found.");
            }

            // Call the business logic to delete the applicant education record
            _applicantEducationLogic.Delete(id);

            return NoContent(); // Successfully deleted
        }

        public ActionResult PutApplicantEducation(ApplicantEducationPoco[] applicantEducationPocos)
        {
            throw new NotImplementedException();
        }

        public ActionResult PostApplicantEducation(ApplicantEducationPoco[] applicantEducationPocos)
        {
            throw new NotImplementedException();
        }

        public ActionResult DeleteApplicantEducation(ApplicantEducationPoco[] applicantEducationPocos)
        {
            throw new NotImplementedException();
        }
    }
}
