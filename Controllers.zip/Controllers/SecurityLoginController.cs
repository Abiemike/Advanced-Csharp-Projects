﻿using CareerCloud.BusinessLogicLayer;
using CareerCloud.Pocos;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;

namespace CareerCloud.Controllers
{
    [Route("api/careercloud/security/login/v1")]
    [ApiController]
    public class SecurityLoginController : ControllerBase
    {
        private readonly SecurityLoginLogic _securityLoginLogic;

        // Constructor for dependency injection of the business logic layer
        public SecurityLoginController(SecurityLoginLogic securityLoginLogic)
        {
            _securityLoginLogic = securityLoginLogic;
        }

        public SecurityLoginController()
        {
        }

        // GET: api/SecurityLogin
        // Get all security login records
        [HttpGet]
        public IActionResult GetAllSecurityLogins()
        {
            List<SecurityLoginPoco> securityLogins = _securityLoginLogic.GetAll();

            if (securityLogins == null || securityLogins.Count == 0)
            {
                return NotFound("No security logins found.");
            }

            return Ok(securityLogins);
        }

        // GET: api/SecurityLogin/{id}
        // Get a specific security login by id
        [HttpGet("{id}")]
        public IActionResult GetSecurityLogin(Guid id)
        {
            SecurityLoginPoco securityLogin = _securityLoginLogic.Get(id);

            if (securityLogin == null)
            {
                return NotFound($"Security login with id {id} not found.");
            }

            return Ok(securityLogin);
        }

        // POST: api/SecurityLogin
        // Create a new security login
        [HttpPost]
        public IActionResult CreateSecurityLogin([FromBody] SecurityLoginPoco securityLogin)
        {
            if (securityLogin == null)
            {
                return BadRequest("Security login cannot be null.");
            }

            // Call the business logic to add the new security login
            _securityLoginLogic.Add(securityLogin);

            return CreatedAtAction(nameof(GetSecurityLogin), new { id = securityLogin.Id }, securityLogin);
        }

        // PUT: api/SecurityLogin/{id}
        // Update an existing security login by id
        [HttpPut("{id}")]
        public IActionResult UpdateSecurityLogin(Guid id, [FromBody] SecurityLoginPoco securityLogin)
        {
            if (securityLogin == null || securityLogin.Id != id)
            {
                return BadRequest("Invalid security login data.");
            }

            // Ensure the security login exists
            var existingSecurityLogin = _securityLoginLogic.Get(id);
            if (existingSecurityLogin == null)
            {
                return NotFound($"Security login with id {id} not found.");
            }

            // Call the business logic to update the security login
            _securityLoginLogic.Update(securityLogin);

            return NoContent(); // Successfully updated
        }

        // DELETE: api/SecurityLogin/{id}
        // Delete a security login by id
        [HttpDelete("{id}")]
        public IActionResult DeleteSecurityLogin(Guid id)
        {
            // Ensure the security login exists before attempting to delete
            var securityLogin = _securityLoginLogic.Get(id);
            if (securityLogin == null)
            {
                return NotFound($"Security login with id {id} not found.");
            }

            // Call the business logic to delete the security login
            _securityLoginLogic.Delete(id);

            return NoContent(); // Successfully deleted
        }

        public ActionResult PostSecurityLogin(SecurityLoginPoco[] securityLoginPocos)
        {
            throw new NotImplementedException();
        }

        public ActionResult PutSecurityLogin(SecurityLoginPoco[] securityLoginPocos)
        {
            throw new NotImplementedException();
        }

        public ActionResult DeleteSecurityLogin(SecurityLoginPoco[] securityLoginPocos)
        {
            throw new NotImplementedException();
        }
    }
}
