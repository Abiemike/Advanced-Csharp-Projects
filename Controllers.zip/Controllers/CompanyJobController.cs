﻿using CareerCloud.BusinessLogicLayer;
using CareerCloud.Pocos;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;

namespace CareerCloud.Controllers
{
    [Route("api/careercloud/company/job/v1")]
    [ApiController]
    public class CompanyJobController : ControllerBase
    {
        private readonly CompanyJobLogic _companyJobLogic;

        // Constructor to inject CompanyJobLogic
        public CompanyJobController(CompanyJobLogic companyJobLogic)
        {
            _companyJobLogic = companyJobLogic;
        }

        public CompanyJobController()
        {
        }

        // GET: api/CompanyJobs
        [HttpGet]
        public IActionResult GetAllCompanyJobs()
        {
            List<CompanyJobPoco> companyJobs = _companyJobLogic.GetAll();

            if (companyJobs == null || companyJobs.Count == 0)
            {
                return NotFound("No company jobs found.");
            }

            return Ok(companyJobs);
        }

        // GET: api/CompanyJobs/{id}
        [HttpGet("{id}")]
        public IActionResult GetCompanyJob(Guid id)
        {
            CompanyJobPoco companyJob = _companyJobLogic.Get(id);

            if (companyJob == null)
            {
                return NotFound($"Company Job with id {id} not found.");
            }

            return Ok(companyJob);
        }

        // POST: api/CompanyJobs
        [HttpPost]
        public IActionResult CreateCompanyJob([FromBody] CompanyJobPoco companyJob)
        {
            if (companyJob == null)
            {
                return BadRequest("Company job cannot be null.");
            }

            _companyJobLogic.Add(companyJob);

            return CreatedAtAction(nameof(GetCompanyJob), new { id = companyJob.Id }, companyJob);
        }

        // PUT: api/CompanyJobs/{id}
        [HttpPut("{id}")]
        public IActionResult UpdateCompanyJob(Guid id, [FromBody] CompanyJobPoco companyJob)
        {
            if (companyJob == null || companyJob.Id != id)
            {
                return BadRequest("Invalid company job data.");
            }

            var existingCompanyJob = _companyJobLogic.Get(id);
            if (existingCompanyJob == null)
            {
                return NotFound($"Company Job with id {id} not found.");
            }

            _companyJobLogic.Update(companyJob);

            return NoContent();
        }

        // DELETE: api/CompanyJobs/{id}
        [HttpDelete("{id}")]
        public IActionResult DeleteCompanyJob(Guid id)
        {
            var companyJob = _companyJobLogic.Get(id);
            if (companyJob == null)
            {
                return NotFound($"Company Job with id {id} not found.");
            }

            _companyJobLogic.Delete(id);

            return NoContent();
        }

        public IActionResult DeleteCompanyJob(CompanyJobPoco[] companyJobPocos)
        {
            throw new NotImplementedException();
        }

        public ActionResult PostCompanyJob(CompanyJobPoco[] companyJobPocos)
        {
            throw new NotImplementedException();
        }

        public ActionResult PutCompanyJob(CompanyJobPoco[] companyJobPocos)
        {
            throw new NotImplementedException();
        }
    }
}
