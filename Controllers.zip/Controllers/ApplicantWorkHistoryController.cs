﻿using CareerCloud.BusinessLogicLayer;
using CareerCloud.Pocos;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;

namespace CareerCloud.Controllers
{
    [Route("api/careercloud/applicant/workhistory/v1")]
    [ApiController]
    public class ApplicantWorkHistoryController : ControllerBase
    {
        private readonly ApplicantWorkHistoryLogic _applicantWorkHistoryLogic;

        // Constructor for dependency injection of the business logic layer
        public ApplicantWorkHistoryController(ApplicantWorkHistoryLogic applicantWorkHistoryLogic)
        {
            _applicantWorkHistoryLogic = applicantWorkHistoryLogic;
        }

        public ApplicantWorkHistoryController()
        {
        }

        // GET: api/ApplicantWorkHistory
        // Get all applicant work histories
        [HttpGet]
        public IActionResult GetAllApplicantWorkHistories()
        {
            List<ApplicantWorkHistoryPoco> applicantWorkHistories = _applicantWorkHistoryLogic.GetAll();

            if (applicantWorkHistories == null || applicantWorkHistories.Count == 0)
            {
                return NotFound("No applicant work histories found.");
            }

            return Ok(applicantWorkHistories);
        }

        // GET: api/ApplicantWorkHistory/{id}
        // Get a specific applicant work history by id
        [HttpGet("{id}")]
        public IActionResult GetApplicantWorkHistory(Guid id)
        {
            ApplicantWorkHistoryPoco applicantWorkHistory = _applicantWorkHistoryLogic.Get(id);

            if (applicantWorkHistory == null)
            {
                return NotFound($"Applicant Work History with id {id} not found.");
            }

            return Ok(applicantWorkHistory);
        }

        // POST: api/ApplicantWorkHistory
        // Create a new applicant work history
        [HttpPost]
        public IActionResult CreateApplicantWorkHistory([FromBody] ApplicantWorkHistoryPoco applicantWorkHistory)
        {
            if (applicantWorkHistory == null)
            {
                return BadRequest("Applicant work history cannot be null.");
            }

            // Call the business logic to add the new applicant work history
            _applicantWorkHistoryLogic.Add(applicantWorkHistory);

            return CreatedAtAction(nameof(GetApplicantWorkHistory), new { id = applicantWorkHistory.Id }, applicantWorkHistory);
        }

        // PUT: api/ApplicantWorkHistory/{id}
        // Update an existing applicant work history by id
        [HttpPut("{id}")]
        public IActionResult UpdateApplicantWorkHistory(Guid id, [FromBody] ApplicantWorkHistoryPoco applicantWorkHistory)
        {
            if (applicantWorkHistory == null || applicantWorkHistory.Id != id)
            {
                return BadRequest("Invalid applicant work history data.");
            }

            // Ensure the applicant work history exists
            var existingApplicantWorkHistory = _applicantWorkHistoryLogic.Get(id);
            if (existingApplicantWorkHistory == null)
            {
                return NotFound($"Applicant Work History with id {id} not found.");
            }

            // Call the business logic to update the applicant work history
            _applicantWorkHistoryLogic.Update(applicantWorkHistory);

            return NoContent(); // Successfully updated
        }

        // DELETE: api/ApplicantWorkHistory/{id}
        // Delete an applicant work history by id
        [HttpDelete("{id}")]
        public IActionResult DeleteApplicantWorkHistory(Guid id)
        {
            // Ensure the applicant work history exists before attempting to delete
            var applicantWorkHistory = _applicantWorkHistoryLogic.Get(id);
            if (applicantWorkHistory == null)
            {
                return NotFound($"Applicant Work History with id {id} not found.");
            }

            // Call the business logic to delete the applicant work history
            _applicantWorkHistoryLogic.Delete(id);

            return NoContent(); // Successfully deleted
        }

        public ActionResult PutApplicantWorkHistory(ApplicantWorkHistoryPoco[] applicantWorkHistoryPocos)
        {
            throw new NotImplementedException();
        }

        public ActionResult PostApplicantWorkHistory(ApplicantWorkHistoryPoco[] applicantWorkHistoryPocos)
        {
            throw new NotImplementedException();
        }

        public ActionResult DeleteApplicantWorkHistory(ApplicantWorkHistoryPoco[] applicantWorkHistoryPocos)
        {
            throw new NotImplementedException();
        }
    }
}
