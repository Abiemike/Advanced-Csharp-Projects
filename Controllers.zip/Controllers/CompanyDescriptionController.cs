﻿using CareerCloud.BusinessLogicLayer;
using CareerCloud.Pocos;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;

namespace CareerCloud.Controllers
{
    [Route("api/careercloud/company/description/v1")]
    [ApiController]
    public class CompanyDescriptionController : ControllerBase
    {
        private readonly CompanyDescriptionLogic _companyDescriptionLogic;

        // ✅ Constructor for dependency injection
        public CompanyDescriptionController(CompanyDescriptionLogic companyDescriptionLogic)
        {
            _companyDescriptionLogic = companyDescriptionLogic;
        }

        public CompanyDescriptionController()
        {
        }

        [HttpGet("{id}")]
        public ActionResult<CompanyDescriptionPoco> GetCompanyDescriptions(Guid id)
        {
            var companyDescription = _companyDescriptionLogic.Get(id);

            if (companyDescription == null)
            {
                return NotFound($"Company Description with id {id} not found.");
            }

            return Ok(companyDescription);
        }

        [HttpGet]
        public ActionResult<IEnumerable<CompanyDescriptionPoco>> GetAllCompanyDescriptions()
        {
            var companyDescriptions = _companyDescriptionLogic.GetAll();

            if (companyDescriptions == null || companyDescriptions.Count == 0)
            {
                return NotFound("No company descriptions found.");
            }

            return Ok(companyDescriptions);
        }

        [HttpPost]
        public ActionResult CreateCompanyDescription([FromBody] CompanyDescriptionPoco companyDescription)
        {
            if (companyDescription == null)
            {
                return BadRequest("Company description cannot be null.");
            }

            _companyDescriptionLogic.Add(new CompanyDescriptionPoco[] { companyDescription });

            return CreatedAtAction(nameof(GetCompanyDescriptions), new { id = companyDescription.Id }, companyDescription);
        }

        [HttpPut("{id}")]
        public ActionResult UpdateCompanyDescription(Guid id, [FromBody] CompanyDescriptionPoco companyDescription)
        {
            if (companyDescription == null || companyDescription.Id != id)
            {
                return BadRequest("Invalid company description data.");
            }

            var existingCompanyDescription = _companyDescriptionLogic.Get(id);
            if (existingCompanyDescription == null)
            {
                return NotFound($"Company Description with id {id} not found.");
            }

            _companyDescriptionLogic.Update(new CompanyDescriptionPoco[]{ companyDescription });

            return NoContent();
        }

        [HttpDelete("{id}")]
        public ActionResult DeleteCompanyDescription(Guid id)
        {
            var companyDescription = _companyDescriptionLogic.Get(id);
            if (companyDescription == null)
            {
                return NotFound($"Company Description with id {id} not found.");
            }

            _companyDescriptionLogic.Delete(new CompanyDescriptionPoco[] { companyDescription });

            return NoContent();
        }

        [HttpDelete]
        public ActionResult DeleteCompanyDescriptions([FromBody] CompanyDescriptionPoco[] companyDescriptions)
        {
            if (companyDescriptions == null || companyDescriptions.Length == 0)
            {
                return BadRequest("No company descriptions provided for deletion.");
            }

            _companyDescriptionLogic.Delete(companyDescriptions);

            return NoContent();
        }

        [HttpPut]
        public ActionResult PutCompanyDescriptions([FromBody] CompanyDescriptionPoco[] companyDescriptions)
        {
            if (companyDescriptions == null || companyDescriptions.Length == 0)
            {
                return BadRequest("No company descriptions provided for update.");
            }

            _companyDescriptionLogic.Update(companyDescriptions);

            return NoContent();
        }

        [HttpPost("bulk")]
        public ActionResult PostCompanyDescriptions([FromBody] CompanyDescriptionPoco[] companyDescriptions)
        {
            if (companyDescriptions == null || companyDescriptions.Length == 0)
            {
                return BadRequest("No company descriptions provided.");
            }

            _companyDescriptionLogic.Add(companyDescriptions);

            return Ok("Company descriptions added successfully.");
        }

        public ActionResult PostCompanyDescription(CompanyDescriptionPoco[] companyDescriptionPocos)
        {
            throw new NotImplementedException();
        }

        public object DeleteCompanyDescription(CompanyDescriptionPoco[] companyDescriptionPocos)
        {
            throw new NotImplementedException();
        }

        public ActionResult PutCompanyDescription(CompanyDescriptionPoco[] companyDescriptionPocos)
        {
            throw new NotImplementedException();
        }

        public ActionResult GetCompanyDescription(Guid id)
        {
            throw new NotImplementedException();
        }
    }
}
